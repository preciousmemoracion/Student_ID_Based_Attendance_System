<?php
require_once 'db.php';

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT id, full_name, username, password, role FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['role']      = $user['role'];
            header('Location: dashboard.php');
            exit();
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Lung Cancer Prediction System</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">
    <div class="auth-split">
        <div class="auth-left">
            <div class="auth-left-content">
                <div class="auth-brand">
                    <div class="brand-icon">
                        <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20 4C11.163 4 4 11.163 4 20s7.163 16 16 16 16-7.163 16-16S28.837 4 20 4z" fill="rgba(255,255,255,0.15)"/>
                            <path d="M14 16c0-3.314 2.686-6 6-6s6 2.686 6 6v2c0 1.105-.895 2-2 2h-8c-1.105 0-2-.895-2-2v-2z" fill="white"/>
                            <path d="M12 22h16v2a6 6 0 01-6 6h-4a6 6 0 01-6-6v-2z" fill="rgba(255,255,255,0.7)"/>
                        </svg>
                    </div>
                    <h1 class="brand-name">LungCare<span>AI</span></h1>
                </div>
                <div class="auth-hero-text">
                    <h2>Early Detection<br>Saves Lives</h2>
                    <p>Advanced lung cancer risk prediction powered by clinical data analysis and machine learning.</p>
                </div>
                <div class="auth-stats">
                    <div class="auth-stat"><span class="stat-num">309+</span><span class="stat-label">Dataset Records</span></div>
                    <div class="auth-stat"><span class="stat-num">15</span><span class="stat-label">Risk Factors</span></div>
                    <div class="auth-stat"><span class="stat-num">97%</span><span class="stat-label">Accuracy</span></div>
                </div>
            </div>
        </div>
        <div class="auth-right">
            <div class="auth-form-container">
                <div class="auth-form-header">
                    <h2>Welcome back</h2>
                    <p>Sign in to your account to continue</p>
                </div>
                <?php if ($error): ?>
                    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <form method="POST" class="auth-form">
                    <div class="form-group">
                        <label>Username or Email</label>
                        <input type="text" name="username" placeholder="Enter your username or email" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <div class="input-wrap">
                            <input type="password" name="password" id="passwordInput" placeholder="Enter your password" required>
                            <button type="button" class="toggle-pw" onclick="togglePassword()">
                                <svg id="eyeIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary full-width">Sign In</button>
                </form>
                <p class="auth-switch">Don't have an account? <a href="register.php">Register here</a></p>
            </div>
        </div>
    </div>
    <script>
        function togglePassword() {
            const input = document.getElementById('passwordInput');
            input.type = input.type === 'password' ? 'text' : 'password';
        }
    </script>
</body>
</html>
