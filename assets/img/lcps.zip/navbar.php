<?php
$current = basename($_SERVER['PHP_SELF']);
$user = getCurrentUser();
?>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div class="brand-icon-sm">
            <svg viewBox="0 0 40 40" fill="none">
                <path d="M20 4C11.163 4 4 11.163 4 20s7.163 16 16 16 16-7.163 16-16S28.837 4 20 4z" fill="rgba(255,255,255,0.15)"/>
                <path d="M14 16c0-3.314 2.686-6 6-6s6 2.686 6 6v2c0 1.105-.895 2-2 2h-8c-1.105 0-2-.895-2-2v-2z" fill="white"/>
                <path d="M12 22h16v2a6 6 0 01-6 6h-4a6 6 0 01-6-6v-2z" fill="rgba(255,255,255,0.7)"/>
            </svg>
        </div>
        <span class="sidebar-brand-name">LungCare<em>AI</em></span>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section-label">Main</div>
        <a href="dashboard.php" class="nav-item <?= $current === 'dashboard.php' ? 'active' : '' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            <span>Dashboard</span>
        </a>
        <a href="prediction.php" class="nav-item <?= $current === 'prediction.php' ? 'active' : '' ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
            <span>Prediction</span>
        </a>
    </nav>

    <div class="sidebar-footer">
        <div class="sidebar-user">
            <div class="user-avatar"><?= strtoupper(substr($user['full_name'], 0, 1)) ?></div>
            <div class="user-info">
                <span class="user-name"><?= htmlspecialchars($user['full_name']) ?></span>
                <span class="user-role"><?= ucfirst($user['role']) ?></span>
            </div>
        </div>
        <a href="logout.php" class="nav-item logout-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            <span>Logout</span>
        </a>
    </div>
</aside>

<div class="topbar">
    <button class="sidebar-toggle" id="sidebarToggle">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
    </button>
    <div class="topbar-title">
        <?php if ($current === 'dashboard.php'): ?>
            <span>Dashboard Overview</span>
        <?php elseif ($current === 'prediction.php'): ?>
            <span>Lung Cancer Prediction</span>
        <?php endif; ?>
    </div>
    <div class="topbar-right">
        Hello, <strong><?= htmlspecialchars($user['full_name']) ?></strong>
    </div>
</div>
