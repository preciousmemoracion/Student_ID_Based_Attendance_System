<?php
require_once 'db.php';
requireLogin();
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prediction — LungCareAI</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="app-page">
    <?php include 'navbar.php'; ?>

    <main class="main-content">
        <div class="page-header">
            <h1 class="page-title">Lung Cancer Prediction</h1>
            <p class="page-subtitle">Fill in the patient's details to assess lung cancer risk</p>
        </div>

        <div class="prediction-layout">
            <!-- Form -->
            <div class="prediction-form-card">
                <form id="predictionForm">
                    <div class="form-section">
                        <div class="form-section-title">
                            <div class="section-num">1</div>
                            <span>Patient Information</span>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Gender</label>
                                <select name="gender" required>
                                    <option value="">Select gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Age</label>
                                <input type="number" name="age" min="1" max="120" placeholder="e.g. 55" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <div class="form-section-title">
                            <div class="section-num">2</div>
                            <span>Lifestyle & Habits</span>
                        </div>
                        <div class="toggle-grid">
                            <?php
                            $lifestyle = [
                                'smoking'          => ['Smoking',          'Does the patient smoke?'],
                                'alcohol_consuming' => ['Alcohol Consuming','Does the patient consume alcohol?'],
                                'peer_pressure'    => ['Peer Pressure',    'Is the patient under peer pressure?'],
                            ];
                            foreach ($lifestyle as $name => [$label, $hint]): ?>
                            <div class="toggle-item">
                                <div class="toggle-info">
                                    <span class="toggle-label"><?= $label ?></span>
                                    <span class="toggle-hint"><?= $hint ?></span>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="<?= $name ?>" value="1">
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-section">
                        <div class="form-section-title">
                            <div class="section-num">3</div>
                            <span>Symptoms & Conditions</span>
                        </div>
                        <div class="toggle-grid">
                            <?php
                            $symptoms = [
                                'yellow_fingers'        => ['Yellow Fingers',       'Yellowing of finger tips?'],
                                'anxiety'               => ['Anxiety',              'Experiencing anxiety?'],
                                'chronic_disease'       => ['Chronic Disease',      'Has a chronic disease?'],
                                'fatigue'               => ['Fatigue',              'Persistent fatigue?'],
                                'allergy'               => ['Allergy',              'Has allergies?'],
                                'wheezing'              => ['Wheezing',             'Wheezing when breathing?'],
                                'coughing'              => ['Coughing',             'Persistent cough?'],
                                'shortness_of_breath'   => ['Shortness of Breath',  'Difficulty breathing?'],
                                'swallowing_difficulty' => ['Swallowing Difficulty','Difficulty swallowing?'],
                                'chest_pain'            => ['Chest Pain',           'Experiencing chest pain?'],
                            ];
                            foreach ($symptoms as $name => [$label, $hint]): ?>
                            <div class="toggle-item">
                                <div class="toggle-info">
                                    <span class="toggle-label"><?= $label ?></span>
                                    <span class="toggle-hint"><?= $hint ?></span>
                                </div>
                                <label class="toggle-switch">
                                    <input type="checkbox" name="<?= $name ?>" value="1">
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <button type="submit" class="btn-primary full-width btn-large" id="submitBtn">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
                        Run Prediction
                    </button>
                </form>
            </div>

            <!-- Result Panel -->
            <div class="result-panel" id="resultPanel">
                <div class="result-placeholder" id="resultPlaceholder">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <p>Fill out the form and click <strong>Run Prediction</strong> to see the result here.</p>
                </div>
                <div class="result-content" id="resultContent" style="display:none">
                    <div class="result-header" id="resultHeader">
                        <div class="result-icon" id="resultIcon"></div>
                        <div class="result-verdict" id="resultVerdict"></div>
                        <div class="result-level" id="resultLevel"></div>
                    </div>
                    <div class="result-score-wrap">
                        <span class="result-score-label">Risk Score</span>
                        <div class="result-score-bar">
                            <div class="result-score-fill" id="resultScoreFill"></div>
                        </div>
                        <span class="result-score-val" id="resultScoreVal"></span>
                    </div>
                    <div class="result-factors" id="resultFactors"></div>
                    <div class="result-note">
                        <strong>Note:</strong> This prediction is based on a rule-based scoring model. It is not a medical diagnosis. Please consult a licensed physician for proper evaluation.
                    </div>
                    <button class="btn-outline full-width" onclick="resetForm()">Run Another Prediction</button>
                </div>
            </div>
        </div>

        <!-- History Table -->
        <div class="table-card" style="margin-top:2rem">
            <div class="table-header">
                <h3>My Prediction History</h3>
                <button class="btn-sm" onclick="loadHistory()">Refresh</button>
            </div>
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Gender</th>
                            <th>Age</th>
                            <th>Risk Score</th>
                            <th>Result</th>
                            <th>Risk Level</th>
                        </tr>
                    </thead>
                    <tbody id="historyBody">
                        <tr><td colspan="7" class="table-empty">Loading...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        document.getElementById('sidebarToggle').addEventListener('click', () => {
            document.body.classList.toggle('sidebar-open');
        });

        const userId = <?= $user['id'] ?>;

        document.getElementById('predictionForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const btn = document.getElementById('submitBtn');
            btn.disabled = true;
            btn.textContent = 'Analyzing...';

            const formData = new FormData(this);
            const data = Object.fromEntries(formData);

            ['smoking','yellow_fingers','anxiety','peer_pressure','chronic_disease',
             'fatigue','allergy','wheezing','alcohol_consuming','coughing',
             'shortness_of_breath','swallowing_difficulty','chest_pain'].forEach(k => {
                data[k] = data[k] === '1' ? 1 : 0;
            });

            try {
                const res = await fetch('save_prediction.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(data)
                });
                const result = await res.json();
                if (result.success) {
                    showResult(result);
                    loadHistory();
                } else {
                    alert('Error: ' + (result.error || 'Unknown error'));
                }
            } catch(err) {
                alert('Request failed. Please try again.');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg> Run Prediction';
            }
        });

        function showResult(r) {
            document.getElementById('resultPlaceholder').style.display = 'none';
            document.getElementById('resultContent').style.display = 'block';
            const isHigh = r.risk_level === 'High Risk';
            const header = document.getElementById('resultHeader');
            header.className = 'result-header ' + (isHigh ? 'high-risk' : 'low-risk');
            document.getElementById('resultIcon').innerHTML = isHigh
                ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
                : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>';
            document.getElementById('resultVerdict').textContent = 'Lung Cancer: ' + r.result;
            document.getElementById('resultLevel').textContent = r.risk_level;
            const pct = Math.round((r.risk_score / 13) * 100);
            document.getElementById('resultScoreFill').style.width = pct + '%';
            document.getElementById('resultScoreFill').className = 'result-score-fill ' + (isHigh ? 'fill-red' : 'fill-green');
            document.getElementById('resultScoreVal').textContent = r.risk_score + '/13';

            const labels = {
                smoking:'Smoking', yellow_fingers:'Yellow Fingers', anxiety:'Anxiety',
                peer_pressure:'Peer Pressure', chronic_disease:'Chronic Disease',
                fatigue:'Fatigue', allergy:'Allergy', wheezing:'Wheezing',
                alcohol_consuming:'Alcohol Consuming', coughing:'Coughing',
                shortness_of_breath:'Shortness of Breath',
                swallowing_difficulty:'Swallowing Difficulty', chest_pain:'Chest Pain'
            };
            let html = '<div class="factors-title">Present Risk Factors</div><div class="factors-list">';
            for (const [k, label] of Object.entries(labels)) {
                const val = r.factors[k];
                html += `<span class="factor-tag ${val ? 'factor-yes' : 'factor-no'}">${label}</span>`;
            }
            html += '</div>';
            document.getElementById('resultFactors').innerHTML = html;
        }

        function resetForm() {
            document.getElementById('predictionForm').reset();
            document.getElementById('resultPlaceholder').style.display = '';
            document.getElementById('resultContent').style.display = 'none';
        }

        async function loadHistory() {
            const res = await fetch(`get_stats.php?action=my_predictions&user_id=${userId}`);
            const data = await res.json();
            const tbody = document.getElementById('historyBody');
            if (!data.predictions || !data.predictions.length) {
                tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No predictions yet.</td></tr>';
                return;
            }
            tbody.innerHTML = data.predictions.map((p, i) => `
                <tr>
                    <td>${i + 1}</td>
                    <td>${p.created_at}</td>
                    <td>${p.gender}</td>
                    <td>${p.age}</td>
                    <td><span class="score-badge">${p.risk_score}/13</span></td>
                    <td><span class="result-badge result-${p.result.toLowerCase()}">${p.result}</span></td>
                    <td><span class="level-badge level-${p.risk_level === 'High Risk' ? 'high' : 'low'}">${p.risk_level}</span></td>
                </tr>
            `).join('');
        }

        loadHistory();
    </script>
</body>
</html>
