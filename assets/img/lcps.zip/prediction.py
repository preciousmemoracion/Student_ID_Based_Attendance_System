# ============================================================
# Lung Cancer Prediction — Model Training Script
# ============================================================
# Source   : MySQL database (lung_cancer_db.predictions table)
# Target   : LUNG_CANCER result (YES / NO)
# Output   : lung_cancer_model.pkl  — trained model
#            lung_cancer_scaler.pkl — fitted scaler
#            model_report.txt       — evaluation report
#
# Install dependencies:
#   pip install pandas scikit-learn joblib matplotlib seaborn mysql-connector-python
#
# Run AFTER you have saved some predictions via the web app.
# ============================================================

import joblib
import warnings
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import mysql.connector

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    roc_auc_score, roc_curve
)

warnings.filterwarnings('ignore')

# ── Database Config (match your config/db.php) ────────────────────────
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASS = ''
DB_NAME = 'lung_cancer_db'

# ── Output Files ──────────────────────────────────────────────────────
MODEL_OUTPUT  = 'lung_cancer_model.pkl'
SCALER_OUTPUT = 'lung_cancer_scaler.pkl'
REPORT_OUTPUT = 'model_report.txt'
TEST_SIZE     = 0.2
RANDOM_STATE  = 42

# ── Feature Columns (must match predictions table) ────────────────────
FEATURE_COLS = [
    'gender', 'age', 'smoking', 'yellow_fingers', 'anxiety',
    'peer_pressure', 'chronic_disease', 'fatigue', 'allergy',
    'wheezing', 'alcohol_consuming', 'coughing',
    'shortness_of_breath', 'swallowing_difficulty', 'chest_pain'
]

print("=" * 60)
print(" LUNG CANCER PREDICTION — MODEL TRAINING")
print("=" * 60)


# ── 1. Connect to Database ────────────────────────────────────────────
print("\n[1] Connecting to MySQL database...")
try:
    conn = mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME
    )
    print("    Connected successfully.")
except mysql.connector.Error as e:
    print(f"    ERROR: Could not connect to database.\n    {e}")
    exit(1)


# ── 2. Load Data from predictions table ──────────────────────────────
print("\n[2] Loading prediction records from database...")

query = """
    SELECT
        gender, age, smoking, yellow_fingers, anxiety,
        peer_pressure, chronic_disease, fatigue, allergy,
        wheezing, alcohol_consuming, coughing,
        shortness_of_breath, swallowing_difficulty, chest_pain,
        result
    FROM predictions
"""

df = pd.read_sql(query, conn)
conn.close()

print(f"    Rows loaded: {len(df)}")

if len(df) < 20:
    print("\n    WARNING: Not enough data to train a reliable model.")
    print("    Please make at least 20 predictions via the web app first.")
    exit(1)

# Encode gender: Male=1, Female=0
df['gender'] = df['gender'].map({'Male': 1, 'Female': 0})

# Encode result: YES=1, NO=0
df['result'] = df['result'].map({'YES': 1, 'NO': 0})

print(f"\n    Target distribution:")
print(f"    YES (High Risk) : {df['result'].sum()}")
print(f"    NO  (Low Risk)  : {(df['result'] == 0).sum()}")


# ── 3. Feature / Target Split ─────────────────────────────────────────
print("\n[3] Splitting features and target...")

X = df[FEATURE_COLS]
y = df['result']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y
)

print(f"    Train: {X_train.shape[0]} samples | Test: {X_test.shape[0]} samples")


# ── 4. Scaling ────────────────────────────────────────────────────────
print("\n[4] Scaling features...")
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)


# ── 5. Train & Compare Models ─────────────────────────────────────────
print("\n[5] Training and evaluating multiple models...")

models = {
    'Logistic Regression':    LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
    'Random Forest':          RandomForestClassifier(n_estimators=100, random_state=RANDOM_STATE),
    'Gradient Boosting':      GradientBoostingClassifier(n_estimators=100, random_state=RANDOM_STATE),
    'Support Vector Machine': SVC(probability=True, random_state=RANDOM_STATE),
    'K-Nearest Neighbors':    KNeighborsClassifier(n_neighbors=5),
}

results = {}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

print(f"\n    {'Model':<28} {'CV Accuracy':>12} {'Test Accuracy':>14} {'ROC-AUC':>10}")
print("    " + "-" * 66)

for name, model in models.items():
    model.fit(X_train_sc, y_train)
    y_pred   = model.predict(X_test_sc)
    y_prob   = model.predict_proba(X_test_sc)[:, 1]
    cv_score = cross_val_score(model, X_train_sc, y_train, cv=cv, scoring='accuracy').mean()
    test_acc = accuracy_score(y_test, y_pred)
    roc_auc  = roc_auc_score(y_test, y_prob)

    results[name] = {
        'model':    model,
        'cv_acc':   cv_score,
        'test_acc': test_acc,
        'roc_auc':  roc_auc,
        'y_pred':   y_pred,
        'y_prob':   y_prob,
    }

    print(f"    {name:<28} {cv_score:>11.4f}  {test_acc:>13.4f}  {roc_auc:>9.4f}")


# ── 6. Select Best Model ──────────────────────────────────────────────
best_name = max(results, key=lambda k: results[k]['roc_auc'])
best      = results[best_name]
print(f"\n[6] Best model selected: {best_name}")
print(f"    ROC-AUC : {best['roc_auc']:.4f}")
print(f"    Accuracy: {best['test_acc']:.4f}")


# ── 7. Save Model & Scaler ────────────────────────────────────────────
print(f"\n[7] Saving model → {MODEL_OUTPUT}")
joblib.dump(best['model'], MODEL_OUTPUT)
joblib.dump(scaler,        SCALER_OUTPUT)
print(f"    Scaler saved  → {SCALER_OUTPUT}")


# ── 8. Detailed Report ────────────────────────────────────────────────
print("\n[8] Generating evaluation report...")

report_lines = []
report_lines.append("=" * 60)
report_lines.append(" LUNG CANCER PREDICTION — MODEL EVALUATION REPORT")
report_lines.append("=" * 60)
report_lines.append(f"\nBest Model   : {best_name}")
report_lines.append(f"Test Accuracy: {best['test_acc']:.4f}")
report_lines.append(f"ROC-AUC      : {best['roc_auc']:.4f}")
report_lines.append(f"CV Accuracy  : {best['cv_acc']:.4f} (5-fold)")
report_lines.append("\n--- Classification Report ---\n")
report_lines.append(classification_report(
    y_test, best['y_pred'],
    target_names=['No Cancer (0)', 'Cancer (1)']
))
report_lines.append("\n--- Confusion Matrix ---")
cm = confusion_matrix(y_test, best['y_pred'])
report_lines.append(f"TN={cm[0,0]}  FP={cm[0,1]}")
report_lines.append(f"FN={cm[1,0]}  TP={cm[1,1]}")
report_lines.append("\n--- All Models Summary ---")
report_lines.append(f"{'Model':<28} {'CV Acc':>10} {'Test Acc':>10} {'ROC-AUC':>10}")
report_lines.append("-" * 60)
for name, r in results.items():
    report_lines.append(f"{name:<28} {r['cv_acc']:>10.4f} {r['test_acc']:>10.4f} {r['roc_auc']:>10.4f}")

report_lines.append("\n--- Feature Importances ---")
if hasattr(best['model'], 'feature_importances_'):
    importances = best['model'].feature_importances_
    feat_imp = sorted(zip(FEATURE_COLS, importances), key=lambda x: x[1], reverse=True)
    for feat, imp in feat_imp:
        bar = '█' * int(imp * 40)
        report_lines.append(f"  {feat:<25} {imp:.4f}  {bar}")
elif hasattr(best['model'], 'coef_'):
    coefs = best['model'].coef_[0]
    feat_imp = sorted(zip(FEATURE_COLS, coefs), key=lambda x: abs(x[1]), reverse=True)
    for feat, coef in feat_imp:
        report_lines.append(f"  {feat:<25} coef={coef:+.4f}")
else:
    report_lines.append("  Not available for this model type.")

report_text = "\n".join(report_lines)
with open(REPORT_OUTPUT, 'w') as f:
    f.write(report_text)

print(f"    Report saved → {REPORT_OUTPUT}")
print("\n" + report_text)


# ── 9. Plots ──────────────────────────────────────────────────────────
print("\n[9] Saving evaluation plots...")
os.makedirs('plots', exist_ok=True)

# Confusion Matrix
fig, ax = plt.subplots(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
            xticklabels=['No Cancer', 'Cancer'],
            yticklabels=['No Cancer', 'Cancer'])
ax.set_title(f'Confusion Matrix — {best_name}')
ax.set_ylabel('Actual')
ax.set_xlabel('Predicted')
plt.tight_layout()
plt.savefig('plots/confusion_matrix.png', dpi=150)
plt.close()

# ROC Curve
fpr, tpr, _ = roc_curve(y_test, best['y_prob'])
fig, ax = plt.subplots(figsize=(6, 5))
ax.plot(fpr, tpr, color='#0f6fff', lw=2,
        label=f'{best_name} (AUC = {best["roc_auc"]:.4f})')
ax.plot([0, 1], [0, 1], 'k--', lw=1)
ax.set_xlim([0, 1]); ax.set_ylim([0, 1.02])
ax.set_xlabel('False Positive Rate')
ax.set_ylabel('True Positive Rate')
ax.set_title('ROC Curve')
ax.legend(loc='lower right')
plt.tight_layout()
plt.savefig('plots/roc_curve.png', dpi=150)
plt.close()

# Model Comparison
names = list(results.keys())
accs  = [results[n]['test_acc'] for n in names]
aucs  = [results[n]['roc_auc']  for n in names]
x = np.arange(len(names))
w = 0.35
fig, ax = plt.subplots(figsize=(10, 5))
bars1 = ax.bar(x - w/2, accs, w, label='Test Accuracy', color='#0f6fff', alpha=0.85)
bars2 = ax.bar(x + w/2, aucs, w, label='ROC-AUC',       color='#00b4a0', alpha=0.85)
ax.set_xticks(x)
ax.set_xticklabels([n.replace(' ', '\n') for n in names], fontsize=9)
ax.set_ylim([0.5, 1.05])
ax.set_title('Model Comparison')
ax.legend()
ax.bar_label(bars1, fmt='%.3f', fontsize=8)
ax.bar_label(bars2, fmt='%.3f', fontsize=8)
plt.tight_layout()
plt.savefig('plots/model_comparison.png', dpi=150)
plt.close()

# Feature Importance
if hasattr(best['model'], 'feature_importances_'):
    importances = best['model'].feature_importances_
    indices = np.argsort(importances)
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.barh([FEATURE_COLS[i] for i in indices], importances[indices],
            color='#0f6fff', alpha=0.8)
    ax.set_title(f'Feature Importances — {best_name}')
    ax.set_xlabel('Importance')
    plt.tight_layout()
    plt.savefig('plots/feature_importance.png', dpi=150)
    plt.close()

print("    Plots saved to plots/ folder.")

print("\n" + "=" * 60)
print(" TRAINING COMPLETE")
print(f" Model  : {MODEL_OUTPUT}")
print(f" Scaler : {SCALER_OUTPUT}")
print(f" Report : {REPORT_OUTPUT}")
print(f" Plots  : plots/")
print("=" * 60)
