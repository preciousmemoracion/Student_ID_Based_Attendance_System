<?php
require_once 'db.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — LungCareAI</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="app-page">
    <?php include 'navbar.php'; ?>

    <main class="main-content">
        <div class="page-header">
            <h1 class="page-title">Dashboard</h1>
            <p class="page-subtitle">System overview and prediction analytics</p>
        </div>

        <!-- Stat Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-card-accent" style="background:var(--primary)"></div>
                <div class="stat-icon icon-blue">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                </div>
                <div class="stat-info">
                    <span class="stat-label">Total Users</span>
                    <span class="stat-value" id="totalUsers">—</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-accent" style="background:var(--teal)"></div>
                <div class="stat-icon icon-teal">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
                </div>
                <div class="stat-info">
                    <span class="stat-label">Total Predictions</span>
                    <span class="stat-value" id="totalPredictions">—</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-accent" style="background:var(--red)"></div>
                <div class="stat-icon icon-red">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                </div>
                <div class="stat-info">
                    <span class="stat-label">High Risk Cases</span>
                    <span class="stat-value" id="highRisk">—</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-accent" style="background:var(--green)"></div>
                <div class="stat-icon icon-green">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <div class="stat-info">
                    <span class="stat-label">Low Risk Cases</span>
                    <span class="stat-value" id="lowRisk">—</span>
                </div>
            </div>
        </div>

        <!-- Row 1: Predictions over time + Risk Donut -->
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-card-header">
                    <div>
                        <h3>Predictions Over Time</h3>
                        <div class="sub">Total predictions per period</div>
                    </div>
                    <div class="filter-tabs">
                        <button class="filter-tab active" data-filter="day">Day</button>
                        <button class="filter-tab" data-filter="month">Month</button>
                        <button class="filter-tab" data-filter="year">Year</button>
                    </div>
                </div>
                <div style="position:relative;height:220px"><canvas id="predictionsTimeChart"></canvas></div>
            </div>
            <div class="chart-card">
                <div class="chart-card-header"><h3>Risk Distribution</h3></div>
                <div class="chart-legend" id="riskLegend"></div>
                <div style="position:relative;height:190px"><canvas id="riskDonutChart"></canvas></div>
            </div>
        </div>

        <!-- Row 2: Users + Gender + Risk Factors -->
        <div class="charts-grid charts-grid-3">
            <div class="chart-card">
                <div class="chart-card-header"><h3>Users Registered</h3></div>
                <div style="position:relative;height:180px"><canvas id="usersChart"></canvas></div>
            </div>
            <div class="chart-card">
                <div class="chart-card-header"><h3>Gender Distribution</h3></div>
                <div class="chart-legend" id="genderLegend"></div>
                <div style="position:relative;height:160px"><canvas id="genderChart"></canvas></div>
            </div>
            <div class="chart-card">
                <div class="chart-card-header"><h3>Top Risk Factors</h3></div>
                <div style="position:relative;height:180px"><canvas id="riskFactorsChart"></canvas></div>
            </div>
        </div>

        <!-- Row 3: Monthly High vs Low Risk Comparison -->
        <div class="charts-grid charts-grid-full">
            <div class="chart-card">
                <div class="chart-card-header">
                    <div>
                        <h3>Monthly High Risk vs Low Risk</h3>
                        <div class="sub">Side-by-side comparison over the last 12 months</div>
                    </div>
                </div>
                <div style="position:relative;height:240px"><canvas id="riskCompareChart"></canvas></div>
            </div>
        </div>

    </main>

    <script src="assets/js/charts.js"></script>
    <script>
        document.getElementById('sidebarToggle').addEventListener('click', () => {
            document.body.classList.toggle('sidebar-open');
        });
    </script>
</body>
</html>