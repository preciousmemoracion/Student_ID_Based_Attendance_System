<?php
require_once 'db.php';
requireLogin();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']);
    exit();
}

$body = json_decode(file_get_contents('php://input'), true);

$gender = $body['gender'] ?? '';
$age    = intval($body['age'] ?? 0);

if (!$gender || !$age) {
    echo json_encode(['error' => 'Gender and age are required.']);
    exit();
}

$symptom_fields = [
    'smoking', 'yellow_fingers', 'anxiety', 'peer_pressure',
    'chronic_disease', 'fatigue', 'allergy', 'wheezing',
    'alcohol_consuming', 'coughing', 'shortness_of_breath',
    'swallowing_difficulty', 'chest_pain'
];

$factors    = [];
$risk_score = 0;

foreach ($symptom_fields as $field) {
    $val = intval($body[$field] ?? 0);
    $factors[$field] = $val;
    $risk_score += $val;
}

$risk_level = $risk_score >= 7 ? 'High Risk' : 'Low Risk';
$result     = $risk_score >= 7 ? 'YES' : 'NO';
$user_id    = $_SESSION['user_id'];

$stmt = $conn->prepare("INSERT INTO predictions
    (user_id, gender, age, smoking, yellow_fingers, anxiety, peer_pressure,
     chronic_disease, fatigue, allergy, wheezing, alcohol_consuming,
     coughing, shortness_of_breath, swallowing_difficulty, chest_pain,
     result, risk_score, risk_level)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

$stmt->bind_param(
    "isiiiiiiiiiiiiiissi",
    $user_id, $gender, $age,
    $factors['smoking'], $factors['yellow_fingers'], $factors['anxiety'],
    $factors['peer_pressure'], $factors['chronic_disease'], $factors['fatigue'],
    $factors['allergy'], $factors['wheezing'], $factors['alcohol_consuming'],
    $factors['coughing'], $factors['shortness_of_breath'],
    $factors['swallowing_difficulty'], $factors['chest_pain'],
    $result, $risk_score, $risk_level
);

if ($stmt->execute()) {
    echo json_encode([
        'success'    => true,
        'result'     => $result,
        'risk_score' => $risk_score,
        'risk_level' => $risk_level,
        'factors'    => $factors
    ]);
} else {
    echo json_encode(['error' => 'Failed to save prediction.']);
}
