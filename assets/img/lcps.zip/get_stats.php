<?php
require_once 'db.php';
requireLogin();
header('Content-Type: application/json');

$action = $_GET['action'] ?? 'dashboard';

switch ($action) {

    case 'dashboard':
        $stats = [];
        $r = $conn->query("SELECT COUNT(*) as cnt FROM users");
        $stats['total_users'] = $r->fetch_assoc()['cnt'];
        $r = $conn->query("SELECT COUNT(*) as cnt FROM predictions");
        $stats['total_predictions'] = $r->fetch_assoc()['cnt'];
        $r = $conn->query("SELECT COUNT(*) as cnt FROM predictions WHERE risk_level = 'High Risk'");
        $stats['high_risk'] = $r->fetch_assoc()['cnt'];
        $r = $conn->query("SELECT COUNT(*) as cnt FROM predictions WHERE risk_level = 'Low Risk'");
        $stats['low_risk'] = $r->fetch_assoc()['cnt'];
        echo json_encode($stats);
        break;

    case 'predictions_over_time':
        $filter = $_GET['filter'] ?? 'month';
        if ($filter === 'day') {
            $sql = "SELECT DATE_FORMAT(created_at,'%Y-%m-%d') as period, COUNT(*) as cnt
                    FROM predictions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                    GROUP BY period ORDER BY period";
        } elseif ($filter === 'month') {
            $sql = "SELECT DATE_FORMAT(created_at,'%Y-%m') as period, COUNT(*) as cnt
                    FROM predictions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                    GROUP BY period ORDER BY period";
        } else {
            $sql = "SELECT DATE_FORMAT(created_at,'%Y') as period, COUNT(*) as cnt
                    FROM predictions GROUP BY period ORDER BY period";
        }
        $r = $conn->query($sql);
        $data = [];
        while ($row = $r->fetch_assoc()) $data[] = $row;
        echo json_encode(['data' => $data]);
        break;

    case 'users_over_time':
        $sql = "SELECT DATE_FORMAT(created_at,'%Y-%m') as period, COUNT(*) as cnt
                FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                GROUP BY period ORDER BY period";
        $r = $conn->query($sql);
        $data = [];
        while ($row = $r->fetch_assoc()) $data[] = $row;
        echo json_encode(['data' => $data]);
        break;

    case 'gender_distribution':
        $r = $conn->query("SELECT gender, COUNT(*) as cnt FROM predictions GROUP BY gender");
        $data = [];
        while ($row = $r->fetch_assoc()) $data[] = $row;
        echo json_encode(['data' => $data]);
        break;

    case 'risk_factors':
        $fields = ['smoking','yellow_fingers','anxiety','peer_pressure','chronic_disease',
                   'fatigue','allergy','wheezing','alcohol_consuming','coughing',
                   'shortness_of_breath','swallowing_difficulty','chest_pain'];
        $data = [];
        foreach ($fields as $f) {
            $r = $conn->query("SELECT SUM($f) as cnt FROM predictions");
            $cnt = $r->fetch_assoc()['cnt'] ?? 0;
            $data[] = ['factor' => ucwords(str_replace('_',' ',$f)), 'cnt' => intval($cnt)];
        }
        usort($data, fn($a,$b) => $b['cnt'] - $a['cnt']);
        echo json_encode(['data' => array_slice($data, 0, 7)]);
        break;

    case 'risk_compare':
        $sql = "SELECT DATE_FORMAT(created_at,'%Y-%m') as period,
                    SUM(CASE WHEN risk_level='High Risk' THEN 1 ELSE 0 END) as high,
                    SUM(CASE WHEN risk_level='Low Risk'  THEN 1 ELSE 0 END) as low
                FROM predictions
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                GROUP BY period ORDER BY period";
        $r = $conn->query($sql);
        $data = [];
        while ($row = $r->fetch_assoc()) $data[] = $row;
        echo json_encode(['data' => $data]);
        break;

    case 'gender_risk':
        $sql = "SELECT gender,
                    SUM(CASE WHEN risk_level='High Risk' THEN 1 ELSE 0 END) as high,
                    SUM(CASE WHEN risk_level='Low Risk'  THEN 1 ELSE 0 END) as low
                FROM predictions GROUP BY gender";
        $r = $conn->query($sql);
        $data = [];
        while ($row = $r->fetch_assoc()) $data[] = $row;
        echo json_encode(['data' => $data]);
        break;

    case 'age_distribution':
        $sql = "SELECT
                    CASE
                        WHEN age < 30 THEN 'Under 30'
                        WHEN age BETWEEN 30 AND 39 THEN '30–39'
                        WHEN age BETWEEN 40 AND 49 THEN '40–49'
                        WHEN age BETWEEN 50 AND 59 THEN '50–59'
                        WHEN age BETWEEN 60 AND 69 THEN '60–69'
                        WHEN age BETWEEN 70 AND 79 THEN '70–79'
                        ELSE '80+'
                    END as age_group,
                    COUNT(*) as cnt
                FROM predictions
                GROUP BY age_group
                ORDER BY MIN(age)";
        $r = $conn->query($sql);
        $data = [];
        while ($row = $r->fetch_assoc()) $data[] = $row;
        echo json_encode(['data' => $data]);
        break;

    case 'recent_predictions':
        $sql = "SELECT p.gender, p.age, p.risk_score, p.result, p.risk_level,
                        DATE_FORMAT(p.created_at,'%b %d, %Y %h:%i %p') as created_at,
                        u.full_name
                FROM predictions p
                JOIN users u ON p.user_id = u.id
                ORDER BY p.created_at DESC LIMIT 10";
        $r = $conn->query($sql);
        $data = [];
        while ($row = $r->fetch_assoc()) $data[] = $row;
        echo json_encode(['predictions' => $data]);
        break;

    case 'my_predictions':
        $uid = intval($_GET['user_id'] ?? 0);
        if ($uid !== $_SESSION['user_id']) {
            echo json_encode(['error' => 'Unauthorized']); exit();
        }
        $stmt = $conn->prepare("SELECT gender, age, risk_score, result, risk_level,
                                 DATE_FORMAT(created_at,'%b %d, %Y %h:%i %p') as created_at
                                 FROM predictions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['predictions' => $rows]);
        break;

    default:
        echo json_encode(['error' => 'Unknown action']);
}