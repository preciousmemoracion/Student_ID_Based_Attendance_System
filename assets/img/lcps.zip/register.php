<?php
require_once 'db.php';

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if (!$full_name || !$email || !$username || !$password || !$confirm) {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->bind_param("ss", $username, $email);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $error = 'Username or email already exists.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (full_name, email, username, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $full_name, $email, $username, $hashed);
            if ($stmt->execute()) {
                $success = 'Account created! You can now <a href="login.php">log in</a>.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — Lung Cancer Prediction System</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">
    <div class="auth-split">
        <div class="auth-left">
            <div class="auth-left-content">
                <div class="auth-brand">
                    <div class="brand-icon">
                        <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20 4C11.163 4 4 11.163 4 20s7.163 16 16 16 16-7.163 16-16S28.837 4 20 4z" fill="rgba(255,255,255,0.15)"/>
                            <path d="M14 16c0-3.314 2.686-6 6-6s6 2.686 6 6v2c0 1.105-.895 2-2 2h-8c-1.105 0-2-.895-2-2v-2z" fill="white"/>
                            <path d="M12 22h16v2a6 6 0 01-6 6h-4a6 6 0 01-6-6v-2z" fill="rgba(255,255,255,0.7)"/>
                        </svg>
                    </div>
                    <h1 class="brand-name">LungCare<span>AI</span></h1>
                </div>
                <div class="auth-hero-text">
                    <h2>Join Our<br>Health Platform</h2>
                    <p>Create an account to start predicting lung cancer risk using our AI-powered clinical analysis tool.</p>
                </div>
                <div class="auth-features">
                    <div class="auth-feature"><div class="feat-dot"></div><span>Instant risk assessment</span></div>
                    <div class="auth-feature"><div class="feat-dot"></div><span>Save prediction history</span></div>
                    <div class="auth-feature"><div class="feat-dot"></div><span>Visual analytics dashboard</span></div>
                </div>
            </div>
        </div>
        <div class="auth-right">
            <div class="auth-form-container">
                <div class="auth-form-header">
                    <h2>Create Account</h2>
                    <p>Fill in the details below to get started</p>
                </div>
                <?php if ($error): ?>
                    <div class="alert alert-error"><?= $error ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                <?php endif; ?>
                <form method="POST" class="auth-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="full_name" placeholder="Juan dela Cruz" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" placeholder="juandc" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" placeholder="juan@email.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" placeholder="Min. 6 characters" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="confirm_password" placeholder="Repeat password" required>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary full-width">Create Account</button>
                </form>
                <p class="auth-switch">Already have an account? <a href="login.php">Sign in here</a></p>
            </div>
        </div>
    </div>
</body>
</html>
